package com.example.osamanadeem.assignmentflight;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileHandlingExample extends AppCompatActivity {

    private EditText editText;
    private TextView textView;
    private String value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_handling_example);
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.txt_data);
        value = null;
    }

    public void write_text_into_file(View view) {
        String data = editText.getText().toString();
        FileOutputStream OS;
        try {
            OS = openFileOutput("myfile",MODE_PRIVATE);
            OS.write(data.getBytes());
            OS.close();
            Toast.makeText(this, "Done writing!", Toast.LENGTH_SHORT).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void fun(View view) {
        FileInputStream inputStream;
        value = "";
        textView.setText("");
        try {
            inputStream= openFileInput("myfile");
            InputStreamReader reader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String data = bufferedReader.readLine();
            while (data != null)
            {
                value = value + data;
                data=bufferedReader.readLine();
            }
            textView.setText(value);
            bufferedReader.close();
            inputStream.close();
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void del(View view) {
        FileOutputStream fileOutputStream;
        try {
            fileOutputStream = openFileOutput("myfile",MODE_PRIVATE);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public void uppercase(View view) {
        FileInputStream inputStream;
        value = "";
        textView.setText("");
        try {
            inputStream= openFileInput("myfile");
            InputStreamReader reader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String data = bufferedReader.readLine();
            while (data != null)
            {
                data = data.toUpperCase();
                value = value + data;
                data=bufferedReader.readLine();
            }
            textView.setText(value);
            bufferedReader.close();
            inputStream.close();
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
