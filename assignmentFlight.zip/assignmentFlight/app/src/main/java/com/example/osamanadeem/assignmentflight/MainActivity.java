package com.example.osamanadeem.assignmentflight;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void create_sharedprefrences(View view) {

        SharedPreferences.Editor editor =
                getSharedPreferences("myprefrences", MODE_PRIVATE).edit();
        editor.putBoolean("key1",true);
        editor.putInt("key2",20);
        editor.putFloat("key3",3);
        editor.putString("key4","abc");
        editor.putLong("key5",100000000);
        editor.apply();
        Toast.makeText(this, "Done!", Toast.LENGTH_SHORT).show();
    }

    public void show_sharedpreferences(View view) {

        SharedPreferences sharedPreferences =
                getSharedPreferences("myprefrences",MODE_PRIVATE);
        Boolean b = sharedPreferences.getBoolean("key1", true);
        int a = sharedPreferences.getInt("key2", 0);
        Float c = sharedPreferences.getFloat("key3", 0);
        String d = sharedPreferences.getString("key4","");
        Long e = sharedPreferences.getLong("key5", 0);

        Toast.makeText(this, e + "", Toast.LENGTH_SHORT).show();




    }

    public void deleteprefrences(View view) {

        SharedPreferences.Editor editor = getSharedPreferences("myprefrences",MODE_PRIVATE).edit();
        editor.clear().apply();
        Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show();
    }
}
