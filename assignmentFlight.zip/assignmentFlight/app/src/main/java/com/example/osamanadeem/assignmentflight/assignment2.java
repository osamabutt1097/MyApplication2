package com.example.osamanadeem.assignmentflight;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class assignment2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private Spinner spinner;
    private String clas;
    private String[] array;
    private TextView departdate,returndate;
    private EditText departurecity,arrivalcity,adultpassenger,childrenpassenger,luggage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment2);


        init();
        spin();
    }


    public void spin()
    {
        array = getResources().getStringArray(R.array.myaray);
        ArrayAdapter adapter =  ArrayAdapter.createFromResource(this,R.array.myaray,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }
    public void init()
    {
        adultpassenger = findViewById(R.id.editText2);
        childrenpassenger = findViewById(R.id.editText3);
        luggage = findViewById(R.id.editText4);
        departdate = findViewById(R.id.textView7);
        returndate = findViewById(R.id.textView8);
        departurecity = findViewById(R.id.textView3);
        arrivalcity = findViewById(R.id.textView4);
        spinner = findViewById(R.id.spinner);
    }
    public void departdate(View view) {
        Calendar calendar =  Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        departdate.setText(i2 + " "+numtomonth(i1));
                    }
                },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    public void returndate(View view) {
        Calendar calendar =  Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        returndate.setText(i2 + " "  + numtomonth(i1));
                    }
                },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }



    public String numtomonth(int i)
    {
        switch (i) {
            case 0:
                return "Jan";
            case 1:
                return "Feb";
            case 2:
                return "Mar";
            case 3:
                return "Apr";
            case 4:
                return "May";
            case 5:
                return "Jun";
            case 6:
                return "Jul";
            case 7:
                return "Aug";
            case 8:
                return "Sep";
            case 9:
                return "Oct";
            case 10:
                return "Nov";
            case 11:
                return "Dec";
        }
        return null;
    }

    public void submit(View view) {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle("Flight Information")
                .setMessage("Your flight details are as follows: \n ->Departure city: " + departurecity.getText().toString() +
                "\n->Arrival city: " + arrivalcity.getText().toString() + "\n->Adult passengers: " + adultpassenger.getText().toString()
                +"\n->Children Passenger: " + childrenpassenger.getText().toString() + "\n->Luggage weight: " + luggage.getText().toString()
                + "\n->Class: " + clas)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //assignment2.super.onBackPressed();
                         Toast.makeText(assignment2.this, "you will be contacted soon!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel",null);
        android.support.v7.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        //Toast.makeText(this, "Clicked on: " + array[i], Toast.LENGTH_SHORT).show();
        clas = array[i];
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }





}
